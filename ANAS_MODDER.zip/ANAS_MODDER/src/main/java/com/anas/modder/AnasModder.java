package com.anas.modder;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents;
import net.minecraft.client.MinecraftClient;

public class AnasModder implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        
        // 1. Chat Command se Menu kholna (.menu)
        ClientSendMessageEvents.ALLOW_CHAT.register((message) -> {
            if (message.trim().equalsIgnoreCase(".menu")) {
                MinecraftClient.getInstance().execute(() -> {
                    MinecraftClient.getInstance().setScreen(new ModMenuScreen());
                });
                return false;
            }
            return true;
        });

        // 2. HUD (Bloody Smiley) ko render karna
        HudRenderCallback.EVENT.register((drawContext, tickDelta) -> {
            HudButton.render(drawContext, 
                (int) (MinecraftClient.getInstance().mouse.getX() * MinecraftClient.getInstance().getWindow().getScaledWidth() / MinecraftClient.getInstance().getWindow().getWidth()),
                (int) (MinecraftClient.getInstance().mouse.getY() * MinecraftClient.getInstance().getWindow().getScaledHeight() / MinecraftClient.getInstance().getWindow().getHeight()),
                tickDelta
            );
        });

        // 3. Smiley ko Click aur Drag karne ka logic (Game ke andar)
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.currentScreen == null && client.mouse.wasLeftButtonClicked()) {
                double mouseX = client.mouse.getX() * client.getWindow().getScaledWidth() / client.getWindow().getWidth();
                double mouseY = client.mouse.getY() * client.getWindow().getScaledHeight() / client.getWindow().getHeight();
                HudButton.onClick(mouseX, mouseY, 0);
            }
        });

        System.out.println("[ANAS MODDER] HUD Loaded Successfully!");
    }
}