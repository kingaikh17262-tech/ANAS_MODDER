package com.anas.modder;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import java.awt.Color;

public class HudButton {
    public static int x = 10;
    public static int y = 10;
    public static final int SIZE = 40;
    
    private static boolean isDragging = false;
    private static int dragOffsetX = 0;
    private static int dragOffsetY = 0;

    public static void render(DrawContext context, int mouseX, int mouseY, float delta) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.currentScreen instanceof ModMenuScreen) return; // Agar menu khula hai toh smiley mat dikhao

        // Blood Animation timer
        int time = (int) (System.currentTimeMillis() / 500);
        int bloodDrip = (time % 3) * 2;

        // Draw Red Circle (Background)
        context.fill(x, y, x + SIZE, y + SIZE, new Color(200, 0, 0).getRGB());
        
        // Draw Blood Drips (Animated)
        context.fill(x + 10, y + SIZE, x + 14, y + SIZE + 5 + bloodDrip, new Color(150, 0, 0).getRGB());
        context.fill(x + 26, y + SIZE, x + 30, y + SIZE + 2 + (bloodDrip % 4), new Color(150, 0, 0).getRGB());

        // Draw Eyes (White)
        context.fill(x + 10, y + 12, x + 16, y + 18, Color.WHITE.getRGB());
        context.fill(x + 24, y + 12, x + 30, y + 18, Color.WHITE.getRGB());

        // Draw Teeth (White)
        context.fill(x + 10, y + 24, x + 30, y + 32, Color.WHITE.getRGB());
        
        // Draw jagged tooth lines (Red)
        context.fill(x + 15, y + 24, x + 17, y + 32, new Color(200, 0, 0).getRGB());
        context.fill(x + 23, y + 24, x + 25, y + 32, new Color(200, 0, 0).getRGB());

        // Handle Dragging
        if (isDragging) {
            x = mouseX - dragOffsetX;
            y = mouseY - dragOffsetY;
        }
    }

    public static boolean onClick(double mouseX, double mouseY, int button) {
        if (button == 0) { // Left Click / Tap
            if (mouseX >= x && mouseX <= x + SIZE && mouseY >= y && mouseY <= y + SIZE) {
                // Agar smiley ke upar tap hua, toh menu kholo
                MinecraftClient.getInstance().setScreen(new ModMenuScreen());
                return true;
            }
        }
        return false;
    }

    public static boolean onDrag(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (button == 0) {
            if (mouseX >= x && mouseX <= x + SIZE && mouseY >= y && mouseY <= y + SIZE) {
                if (!isDragging) {
                    isDragging = true;
                    dragOffsetX = (int) (mouseX - x);
                    dragOffsetY = (int) (mouseY - y);
                }
                return true;
            }
        }
        return false;
    }

    public static void onRelease(int button) {
        if (button == 0) {
            isDragging = false;
        }
    }
}