package com.anas.modder;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

public class ModMenuScreen extends Screen {
    
    // Hack States
    public static boolean xrayEnabled = false;
    public static boolean espEnabled = false;
    public static boolean aimbotEnabled = false;
    public static boolean aimbowEnabled = false;
    
    // Toggle Buttons
    private ButtonWidget btnXray;
    private ButtonWidget btnEsp;
    private ButtonWidget btnAimbot;
    private ButtonWidget btnAimbow;

    public ModMenuScreen() {
        super(Text.literal("ANAS MODDER"));
    }

    @Override
    protected void init() {
        int centerX = this.width / 2;
        int startY = this.height / 2 - 60;
        int btnWidth = 160;
        int btnHeight = 20;

        // X-Ray Toggle
        btnXray = ButtonWidget.builder(getText("X-RAY", xrayEnabled), button -> {
            xrayEnabled = !xrayEnabled;
            button.setMessage(getText("X-RAY", xrayEnabled));
        }).dimensions(centerX - btnWidth - 10, startY, btnWidth, btnHeight).build();

        // ESP Toggle
        btnEsp = ButtonWidget.builder(getText("ESP", espEnabled), button -> {
            espEnabled = !espEnabled;
            button.setMessage(getText("ESP", espEnabled));
        }).dimensions(centerX + 10, startY, btnWidth, btnHeight).build();

        // Aimbot Toggle
        btnAimbot = ButtonWidget.builder(getText("AIMBOT", aimbotEnabled), button -> {
            aimbotEnabled = !aimbotEnabled;
            button.setMessage(getText("AIMBOT", aimbotEnabled));
        }).dimensions(centerX - btnWidth - 10, startY + 30, btnWidth, btnHeight).build();

        // AimBow Toggle
        btnAimbow = ButtonWidget.builder(getText("AIMBOW", aimbowEnabled), button -> {
            aimbowEnabled = !aimbowEnabled;
            button.setMessage(getText("AIMBOW", aimbowEnabled));
        }).dimensions(centerX + 10, startY + 30, btnWidth, btnHeight).build();

        // Close Button
        ButtonWidget btnClose = ButtonWidget.builder(Text.literal("X").formatted(Formatting.RED), button -> {
            this.close();
        }).dimensions(centerX - 10, startY + 80, 20, 20).build();

        this.addDrawableChild(btnXray);
        this.addDrawableChild(btnEsp);
        this.addDrawableChild(btnAimbot);
        this.addDrawableChild(btnAimbow);
        this.addDrawableChild(btnClose);
    }

    private Text getText(String name, boolean isOn) {
        if (isOn) {
            return Text.literal(name + ": ON").formatted(Formatting.GREEN);
        } else {
            return Text.literal(name + ": OFF").formatted(Formatting.WHITE);
        }
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        // Background - Dark Transparent
        context.fill(0, 0, this.width, this.height, 0x88000000);

        // Menu Box Background (Cyberpunk Style)
        int centerX = this.width / 2;
        int centerY = this.height / 2;
        int boxWidth = 360;
        int boxHeight = 160;

        // Outer Neon Border
        context.fill(centerX - boxWidth/2 - 2, centerY - boxHeight/2 - 2, centerX + boxWidth/2 + 2, centerY + boxHeight/2 + 2, 0xFF00FFCC); // Cyan border
        // Inner Dark Box
        context.fill(centerX - boxWidth/2, centerY - boxHeight/2, centerX + boxWidth/2, centerY + boxHeight/2, 0xEE0A0F1D);

        // Title
        context.drawCenteredTextWithShadow(this.textRenderer, "ANAS MODDER", centerX, centerY - 70, 0xFF0033);

        // Render Buttons
        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean shouldPause() {
        return false; // Game pause nahi hoga jab menu khulega (Multiplayer safe)
    }
} 